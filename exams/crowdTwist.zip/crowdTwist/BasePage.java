
import org.openqa.selenium.WebDriver;

class BasePage {

	protected WebDriver driver;

	BasePage(WebDriver driver){
		this.driver = driver;
	}

}