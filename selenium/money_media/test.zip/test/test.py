from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Firefox()
driver.get("http://0.0.0.0:8080/test.html")
elem = driver.find_element_by_id("test")
elem.click()

elem2 = driver.find_element_by_id("foo")
elem2.send_keys('hello')
str = 'hello'
assert  str in driver.page_source
driver.close()

