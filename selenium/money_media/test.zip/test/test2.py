from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Firefox()
driver.get("http://www.financialadvisoriq.com/?login=1")
elem = driver.find_element_by_id("email")
elem.send_keys('hello')
driver.close()

